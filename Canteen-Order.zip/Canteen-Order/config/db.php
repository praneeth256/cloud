<?php

$servername = "cloud-database.cz097sm5gqeb.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "12345678";
$dbname = "finals";

// Create connection
$conn = mysqli_connect($servername, $username, $password , $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
