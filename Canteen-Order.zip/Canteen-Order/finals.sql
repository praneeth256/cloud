-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2024 at 08:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finals`
--

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `food_id` int(11) NOT NULL,
  `food_name` varchar(255) NOT NULL,
  `food_cat` varchar(255) NOT NULL,
  `food_price` double NOT NULL,
  `food_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`food_id`, `food_name`, `food_cat`, `food_price`, `food_image`) VALUES
(1, 'Aloo Parantha', 'Breakfast', 30, './img/food/Aloo-parantha.jpg'),
(2, 'Chole Bhature', 'Breakfast', 30, './img/food/chole-bhature.jpg'),
(3, 'Masala Dosa', 'Breakfast', 50, './img/food/masala-dosa.jpg'),
(4, 'Pancake', 'Breakfast', 40, './img/food/pancake.jpg'),
(5, 'Pav Bhaji', 'Breakfast', 30, './img/food/pav-bhaji.jpg'),
(6, 'Uttapam', 'Breakfast', 40, './img/food/uttapam.jpg'),
(7, 'Vada Pav', 'Breakfast', 20, './img/food/vada-pav.jpg'),
(8, 'Vada Sambhar', 'Breakfast', 25, './img/food/vada-sambar.jpg'),
(9, 'Butter Naan', 'Lunch', 15, './img/food/butter-nan.jpg'),
(10, 'Caesar Salad', 'Lunch', 50, './img/food/caesar-salad.jpg'),
(11, 'Dal Makhni', 'Lunch', 50, './img/food/dal-makhni.jpg'),
(12, 'Garlic Naan', 'Lunch', 20, './img/food/garlic-nan.jpg'),
(13, 'Kadhai Paneer', 'Lunch', 50, './img/food/kadhai-paneer.jpg'),
(14, 'Lemon Rice', 'Lunch', 30, './img/food/lemon-rice.jpg'),
(15, 'Paneer Butter Masala', 'Lunch', 50, './img/food/paneer-butter-masala.jpg'),
(16, 'Roti', 'Lunch', 10, './img/food/roti.jpg'),
(17, 'Shahi Paneer', 'Lunch', 50, './img/food/shahi-paneer.jpg'),
(18, 'Burger', 'Snacks', 45, './img/food/burger.jpg'),
(19, 'Cheesy Meatballs', 'Snacks', 30, './img/food/cheesy-meatballs.jpg'),
(20, 'Chicken Tikka Wrap', 'Snacks', 50, './img/food/chicken-tikka-wrap.jpg'),
(21, 'Fries', 'Snacks', 25, './img/food/fries.jpg'),
(22, 'Garlic Bread', 'Snacks', 50, './img/food/garlic-bread.jpg'),
(23, 'Momos', 'Snacks', 40, './img/food/momos.jpg'),
(24, 'Pizza', 'Snacks', 100, './img/food/pizza.jpg'),
(25, 'Potato Chilli Shots', 'Snacks', 30, './img/food/potato-chilli-shots.jpg'),
(26, 'Potato Wedges', 'Snacks', 30, './img/food/potato-wedges.jpg'),
(27, 'Samosa', 'Snacks', 20, './img/food/samosa.jpg'),
(28, 'Biryani', 'Dinner', 80, './img/food/biryani.jpg'),
(29, 'Butter Chicken', 'Dinner', 100, './img/food/butter-chicken.jpg'),
(30, 'Chicken Tikka Masala', 'Dinner', 100, './img/food/chicken-tikka-masala.jpg'),
(31, 'Egg Curry', 'Dinner', 100, './img/food/egg-curry.jpg'),
(32, 'Fish Kebab', 'Dinner', 80, './img/food/fish-kebab.jpg'),
(33, 'Rice', 'Dinner', 40, './img/food/rice.jpg'),
(34, 'Soya Chap', 'Dinner', 100, './img/food/soya-chap.jpg'),
(35, 'Tandori Roti', 'Dinner', 20, './img/food/tandori-roti.jpg'),
(36, 'Cheese Cake', 'Desert', 40, './img/food/cheese-cake.jpg'),
(37, 'Chocolate Pastry', 'Desert', 40, './img/food/chocolate-pastry.jpg'),
(38, 'Gulab Jamun', 'Desert', 20, './img/food/gulab-jamun.jpg'),
(39, 'Hazelnut Brownie', 'Desert', 40, './img/food/hazelnut-brownie.jpg'),
(40, 'Lava Cake', 'Desert', 40, './img/food/lava-cake.jpg'),
(41, 'Payasam', 'Desert', 30, './img/food/payasam.jpg'),
(42, 'Rasmalai', 'Desert', 30, './img/food/rasmalai.jpg'),
(43, 'Red Velvet Pastry', 'Desert', 40, './img/food/red-velvet-pastry.jpg'),
(44, '7 up', 'Drinks', 20, './img/food/7-up.jpg'),
(45, 'Fruit Juice', 'Drinks', 20, './img/food/fruit-juice.jpg'),
(46, 'Ice Tea', 'Drinks', 25, './img/food/ice-tea.jpg'),
(47, 'Mango Lassi', 'Drinks', 25, './img/food/mango-lassi.jpg'),
(48, 'Milk Shake', 'Drinks', 25, './img/food/milk-shake.jpg'),
(49, 'Mirinda', 'Drinks', 20, './img/food/mirinda.jpg'),
(50, 'Mountain Dew', 'Drinks', 20, './img/food/mountain-dew.jpg'),
(51, 'Pepsi', 'Drinks', 20, './img/food/pepsi.jpg'),
(52, 'Red Bull', 'Drinks', 20, './img/food/red-bull.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_price` double NOT NULL,
  `order_payment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ordersitems`
--

CREATE TABLE `ordersitems` (
  `id` int(11) NOT NULL,
  `orders_id` int(11) NOT NULL,
  `food_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `food_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_hostel_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_hostel_no`) VALUES
(1, 'PRANEETH', 'yelletipraneeth16@gmail.com', '$2y$10$rZ7pAwf9OCkk4JmgM4j.Q.hY.dVobWkxp22OQX/lgdI6RE380nopa', '429');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `ordersitems`
--
ALTER TABLE `ordersitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ordersitems`
--
ALTER TABLE `ordersitems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
